-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema eazydeals
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema eazydeals
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `eazydeals` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `eazydeals` ;

-- -----------------------------------------------------
-- Table `eazydeals`.`admin`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `eazydeals`.`admin` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NULL DEFAULT NULL,
  `email` VARCHAR(100) NULL DEFAULT NULL,
  `password` VARCHAR(50) NULL DEFAULT NULL,
  `phone` VARCHAR(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 15
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `eazydeals`.`category`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `eazydeals`.`category` (
  `cid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NULL DEFAULT NULL,
  `image` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`cid`))
ENGINE = InnoDB
AUTO_INCREMENT = 24
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `eazydeals`.`product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `eazydeals`.`product` (
  `pid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(250) NOT NULL,
  `description` VARCHAR(500) NULL DEFAULT NULL,
  `price` VARCHAR(20) NOT NULL,
  `quantity` INT NULL DEFAULT NULL,
  `discount` INT NULL DEFAULT NULL,
  `image` VARCHAR(100) NULL DEFAULT NULL,
  `cid` INT NULL DEFAULT NULL,
  PRIMARY KEY (`pid`),
  INDEX `cid_idx` (`cid` ASC) VISIBLE,
  CONSTRAINT `cid`
    FOREIGN KEY (`cid`)
    REFERENCES `eazydeals`.`category` (`cid`))
ENGINE = InnoDB
AUTO_INCREMENT = 59
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `eazydeals`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `eazydeals`.`user` (
  `userid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NULL DEFAULT NULL,
  `email` VARCHAR(45) NULL DEFAULT NULL,
  `password` VARCHAR(45) NULL DEFAULT NULL,
  `phone` VARCHAR(20) NULL DEFAULT NULL,
  `gender` VARCHAR(20) NULL DEFAULT NULL,
  `registerdate` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `address` VARCHAR(250) NULL DEFAULT NULL,
  `city` VARCHAR(100) NULL DEFAULT NULL,
  `pincode` VARCHAR(10) NULL DEFAULT NULL,
  `state` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE,
  UNIQUE INDEX `phone_UNIQUE` (`phone` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 24
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `eazydeals`.`cart`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `eazydeals`.`cart` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `uid` INT NULL DEFAULT NULL,
  `pid` INT NULL DEFAULT NULL,
  `quantity` INT NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `uid_idx` (`uid` ASC) VISIBLE,
  INDEX `pid_idx` (`pid` ASC) VISIBLE,
  CONSTRAINT `pid`
    FOREIGN KEY (`pid`)
    REFERENCES `eazydeals`.`product` (`pid`),
  CONSTRAINT `uid`
    FOREIGN KEY (`uid`)
    REFERENCES `eazydeals`.`user` (`userid`))
ENGINE = InnoDB
AUTO_INCREMENT = 22
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `eazydeals`.`order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `eazydeals`.`order` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `orderid` VARCHAR(100) NULL DEFAULT NULL,
  `status` VARCHAR(100) NULL DEFAULT NULL,
  `paymentType` VARCHAR(100) NULL DEFAULT NULL,
  `userId` INT NULL DEFAULT NULL,
  `date` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `userId_idx` (`userId` ASC) VISIBLE,
  CONSTRAINT `userId`
    FOREIGN KEY (`userId`)
    REFERENCES `eazydeals`.`user` (`userid`))
ENGINE = InnoDB
AUTO_INCREMENT = 32
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `eazydeals`.`ordered_product`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `eazydeals`.`ordered_product` (
  `oid` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NULL DEFAULT NULL,
  `quantity` INT NULL DEFAULT NULL,
  `price` VARCHAR(45) NULL DEFAULT NULL,
  `image` VARCHAR(100) NULL DEFAULT NULL,
  `orderid` INT NULL DEFAULT NULL,
  PRIMARY KEY (`oid`),
  INDEX `orderid_idx` (`orderid` ASC) VISIBLE,
  CONSTRAINT `orderid`
    FOREIGN KEY (`orderid`)
    REFERENCES `eazydeals`.`order` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 30
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
